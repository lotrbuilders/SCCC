int main() {

    while (1) {
        int a = 2;
    }

    return a;
}