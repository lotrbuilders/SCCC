int main() {
    do
        3;
    while (4)
}