int main() {
    int a = 2;
    int b = 1;
    a > b ? a = 1 : a = 0;
    return a;
}