int main() {
    int a = 0;
    if (1)
        return 1;
    else
        return 2;
    else
        return 3;
}