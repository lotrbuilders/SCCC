int main() {
    int a = 1;
    int b = 2;
    int flag = 0;

    return a > b ? 5 : flag ? 6 : 7;
}