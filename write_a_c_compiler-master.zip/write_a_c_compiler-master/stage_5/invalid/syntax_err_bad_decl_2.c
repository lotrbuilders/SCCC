int main() {
    int foo bar = 3;
    return bar;
}