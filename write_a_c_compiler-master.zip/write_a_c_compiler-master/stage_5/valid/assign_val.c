int main() {
    int a;
    int b = a = 0;
    return b;
}