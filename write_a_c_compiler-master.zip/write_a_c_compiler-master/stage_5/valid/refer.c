int main() {
    int a = 2;
    return a;
}