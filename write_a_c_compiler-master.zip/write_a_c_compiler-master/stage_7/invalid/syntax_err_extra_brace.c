int main() {
    if(0){
        return 1;
    }}
    return 2;
}