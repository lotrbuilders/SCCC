int main() {
    return 6 / 3 / 2;
}