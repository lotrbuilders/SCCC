int foo(int x) {
    int x = 3;
}

int main() {
    foo(1);
}