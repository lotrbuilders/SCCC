int foo(int a);

int main() {
    return 5;
}

int foo(int a, int b) {
    return 4;
}