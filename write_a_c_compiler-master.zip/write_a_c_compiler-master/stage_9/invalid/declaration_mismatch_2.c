int foo(int a, int b);

int main() {
    return 5;
}

int foo(int a) {
    return 4;
}