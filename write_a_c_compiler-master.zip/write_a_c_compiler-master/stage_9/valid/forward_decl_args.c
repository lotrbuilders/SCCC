int foo(int a);

int main(){
    return foo(3);
}

int foo(int a){
    return a + 1;
}